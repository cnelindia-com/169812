import React from "react";

// ProductDetails Component to display product details
const ProductDetails = ({ product }) => {
  return (
    <div id="product-details">
      <h2>{product.Title}</h2>
      <p><strong>Vendor:</strong> {product.VendorName}</p>
      <p><strong>Brand:</strong> {product.BrandName}</p>
      <p><strong>Price:</strong> {product.Price.ConvertedPrice}</p>
      <p><strong>Original Price:</strong> ${product.Price.OriginalPrice}</p>
      <p><strong>Category:</strong> {product.CategoryId}</p>
      <p><strong>Product URL:</strong> <a href={product.TaobaoItemUrl} target="_blank" rel="noopener noreferrer">Click Here</a></p>

      <h3>Images</h3>
      <div id="product-images">
        {product.Pictures.map((image, index) => (
          <img
            key={index}
            src={image.Url}
            alt={`Product Image ${index + 1}`}
            style={{ width: "200px", margin: "10px" }}
          />
        ))}
      </div>
    </div>
  );
};

export default ProductDetails;
