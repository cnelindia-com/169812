import React, { useState, useEffect } from 'react';
import { CRow, CCol, CCard, CCardBody, CButton, CFormLabel, CFormSelect, CFormCheck, CFormInput, CCardHeader, CModal, CModalHeader, CModalTitle, CModalBody, CModalFooter } from '@coreui/react';
import DynamicForm from "./DynmicForm";
import BASE_URL from "../../.././config";

const Colors = () => {
  const [apitype, setApitype] = useState('');
  const [language, setLanguage] = useState('');
  const [category, setCategory] = useState('');
  const [vendor, setVendor] = useState('');
  const [seller, setseller] = useState('');
  const [sellerurl, setSellerUrl] = useState('');
  const [provider, setProvider] = useState('');
  const [providerurl, setProviderUrl] = useState('');
  const [itemid, setItemid] = useState('');
  const [itemtitle, setItemtitle] = useState('');
  const [brand, setBrand] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [condition, setCondition] = useState('');
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [selectAll, setSelectAll] = useState(false); // Track "Select All" checkbox state
  const [formError, setFormError] = useState(''); // New state for form error message
  // console.log("BASE_URL",BASE_URL);
  const [selectedForm, setSelectedForm] = useState("TMAPI");

  const handleCheckboxChanged = (event) => {
    setSelectedForm(event.target.value);
  };

  // Handle the form submission for filtering products
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Validate if at least one field is filled
    if (
      !category.trim() &&
      !vendor.trim() &&
      !itemtitle.trim() &&
      !brand.trim() &&
      !itemid.trim() &&
      !provider.trim() &&
      !seller.trim() &&
      !sellerurl.trim()
    ) {
      setFormError('At least one field must be filled, such as Category, Item Id , Item Title, or Brand.');
      return;
    }

    setFormError('');
    setLoading(true);
    setProgress(10);   // Start progress bar from 10%
    setSuccessMessage(''); // Clear success message from previous imports
    setErrorMessage('');

    const formData = {
      category,
      itemid,
      itemtitle,
      brand,
      minPrice,
      maxPrice,
      condition,
      vendor,
      provider,
      language,
      seller,
      sellerurl,
      apitype
    };

    console.log("fgg", formData);

    let progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev < 90) {
          return prev + 10;  // Increase the progress bar incrementally
        }
        return prev;  // Stop progressing when it reaches 90%
      });
    }, 300);


    if (itemid) {
      await fetchProductDetailsByItemId(itemid); // Wait for itemid fetch
    }

    if (sellerurl) {
      await fetchproductbyseller(sellerurl); // Pass sellerurl
    }
    // Otherwise, use seller
    if (seller) {
      await fetchproductbyseller(seller); // Pass seller
    }

    if (provider) {
      await fetchProductDetailsByprovidername(provider); // Wait for provider fetch
    }
    else {
      // Build the URL with query parameters for fetching products
      const url = new URL("/get_filterproduct_api.php?task=getproducts", BASE_URL);
      Object.keys(formData).forEach((key) => {
        if (formData[key]) {
          url.searchParams.append(key, formData[key]);
        }
      });

      try {
        const response = await fetch(url, {
          method: "GET",
          headers: {
            "Content-Type": "application/json",
          },
        });

        if (!response.ok) throw new Error('Failed to fetch products');

        const data = await response.json();
        console.log(data);

        if (data.Result.Items.Content) {
          setProducts(data.Result.Items.Content);
          setFilteredProducts(data.Result.Items.Content);
          setSuccessMessage('Products fetched successfully!');
        } else {
          setProducts([]);
          setFilteredProducts([]);
          setSuccessMessage('No products found!');
        }
      } catch (error) {
        setErrorMessage(`Not found any product related to your filter`);
      } finally {
        clearInterval(progressInterval);  // Stop the progress bar interval
        setProgress(100);  // Set progress bar to 100% after fetch completes
        setLoading(false); // Set loading to false when done fetching
      }
    }
  };
  const handleClearFilters = () => {
    setCategory('');
    setVendor('');
    setProvider('');
    setProviderUrl('');
    setItemid('');
    setItemtitle('');
    setBrand('');
    setMinPrice('');
    setMaxPrice('');
    setCondition('');
    setLanguage('');
    setFormError(''); // Clear any form error message
    setFilteredProducts(""); // Reset filtered products to all products
    setSuccessMessage('');
  };

  const handleLanguageChange = (e) => {
    setLanguage(e.target.value);
  };
  const handleCheckboxChange = (id) => {
    const product = filteredProducts.find((product) => product.Id === id);

    setSelectedProducts((prevState) => {
      // Check if the product is already selected
      const isProductSelected = prevState.some((p) => p.Id === id);

      if (isProductSelected) {
        // If already selected, remove it
        return prevState.filter((product) => product.Id !== id);
      } else {
        // If not selected, add it to the selectedProducts array
        return [...prevState, product];
      }
    });
  };


  const fetchProductDetailsByItemId = async (itemid) => {
    try {
      const response = await fetch(`${BASE_URL}/get_filterproduct_api.php?task=getprodcutbyitemid&itemid=${itemid}&language=${language}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) throw new Error('Failed to fetch products');

      const rawResponse = await response.text();  // Get the raw response as text
      // console.log('Raw Response:', rawResponse);  // Log the raw response to see what is returned

      const data = JSON.parse(rawResponse);  // Only parse if it's valid JSON
      // console.log(data);  // Log the parsed response

      if (data && data.OtapiItemInfo) {
        if (Array.isArray(data.OtapiItemInfo)) {
          setProducts(data.OtapiItemInfo);
          setFilteredProducts(data.OtapiItemInfo);
        } else {
          setProducts([data.OtapiItemInfo]);
          setFilteredProducts([data.OtapiItemInfo]);
        }
        setSuccessMessage('Products fetched successfully!');
      } else {
        setProducts([]);
        setFilteredProducts([]);
        setSuccessMessage('No products found!');
      }
    } catch (error) {
      console.error("Error fetching product data: ", error);
      setErrorMessage(`Error: ${error.message}`);
    } finally {
      setProgress(100);  // Set progress to 100% once the request completes
      setLoading(false);
    }
  };
  const fetchproductbyseller = async (seller) => {
    alert(seller);
    try {
      const response = await fetch(`https://localhost/sahabaz/get_sellerinfo.php?task=getprodcutbyseller&seller=${seller}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) throw new Error('Failed to fetch products');

      const rawResponse = await response.text();  // Get the raw response as text
      console.log('Raw Response:', rawResponse);  // Log the raw response to see what is returned

      const data = JSON.parse(rawResponse);  // Only parse if it's valid JSON
      console.log(data);  // Log the parsed response

      if (data) {
        setSuccessMessage('Products fetched successfully!');
      } else {
        setProducts([]);
        setFilteredProducts([]);
        setSuccessMessage('No products found!');
      }
    } catch (error) {
      console.error("Error fetching product data: ", error);
      setErrorMessage(`Error: ${error.message}`);
    } finally {
      setProgress(100);  // Set progress to 100% once the request completes
      setLoading(false);
    }
  };



  const fetchProductDetailsByprovidername = async (provider) => {
    try {
      const response = await fetch(`${BASE_URL}/get_filterproduct_api.php?task=getproductbyprovider&provider=${provider}&language=${language}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      setLoading(true); // Set loading true when request starts

      const rawResponse = await response.text();
      console.log("Raw Response:", rawResponse);  // Log raw response to debug

      const validJsonResponse = rawResponse.replace(/[^}\]]*$/, ''); // Strip out non-JSON data

      const data = JSON.parse(validJsonResponse);

      console.log("Parsed Response:", data);

      if (data && data && data.length > 0) {
        setProducts(data);
        setFilteredProducts(data);
        setSuccessMessage('Products fetched successfully!');
      } else {
        setProducts([]);
        setFilteredProducts([]);
        setSuccessMessage('No products found!');
      }
    } catch (error) {
      console.error("Error fetching product data:", error);
      if (error.name === 'AbortError') {
        setErrorMessage('Request timed out. Please try again.');
      } else {
        setErrorMessage(`Error: ${error.message}`);
      }
    } finally {
      setProgress(100);  // Set progress to 100% once the request completes
      setLoading(false); // Set loading false once done fetching
    }
  };







  // Handle "Select All" checkbox state
  // Handle "Select All" checkbox state
  const handleSelectAllChange = () => {
    if (selectAll) {
      setSelectedProducts([]); // Deselect all products
    } else {
      setSelectedProducts(filteredProducts); // Select all products
    }
    setSelectAll(!selectAll);
  };
  // Handle viewing product details in the modal
  const handleViewDetails = (product) => {
    setSelectedProduct(product);
    setModalVisible(true);
  };

  // Close modal for product details
  const handleCloseModal = () => {
    setModalVisible(false);
  };

  // Handle filtering products based on form input
  const handleFilterChange = (e) => {
    const value = e.target.value;
    setFilteredProducts(
      products.filter(
        (product) =>
          product.Title.toLowerCase().includes(value.toLowerCase()) || product.BrandId.toLowerCase().includes(value.toLowerCase())
      )
    );
  };


  const handleImportSelectedProducts = async () => {
    // Use `selectedProducts` array directly
    const productsToImport = selectAll ? filteredProducts : selectedProducts;

    if (productsToImport.length === 0) {
      setErrorMessage('Please select at least one product.');
      return;
    }

    setLoading(true);
    setSuccessMessage(''); // Clear previous success message
    setErrorMessage(''); // Clear previous error message

    try {
      const response = await fetch(`${BASE_URL}/import_products.php`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ products: productsToImport }),
      });

      const data = await response.json();
      console.log("API Response:", data);  // Log the entire response
      if (!data.productResults) {
        setErrorMessage('Error: No product results found in the response.');
        return;
      }

      console.log("Product Results:", data.productResults);  // Log the productResults

      const productResults = data.productResults;

      // Now filter based on status
      const inserted = productResults.filter(result => result.status === 'inserted');
      const duplicates = productResults.filter(result => result.status === 'duplicate');
      const errors = productResults.filter(result => result.status === 'error');

      console.log("Inserted Products:", inserted);
      console.log("Duplicate Products:", duplicates);
      console.log("Error Products:", errors);

      if (inserted.length > 0) {
        setSuccessMessage(`${inserted.length} products inserted successfully.`);
      }
      if (duplicates.length > 0) {
        setSuccessMessage(`${duplicates.length} products were duplicates.`);
      }
      if (errors.length > 0) {
        setErrorMessage(`${errors.length} products failed to import.`);
      }
    } catch (error) {
      setErrorMessage(`Error importing products: ${error.message}`);
    } finally {
      setProgress(100);  // Set progress to 100% once the request completes
      setLoading(false);
    }


  };




  return (
    <CCard className="mb-4">
      <CCardHeader>
        <h4>Products Import</h4>
      </CCardHeader>
      <CCardBody>
        {/* Display Success or Error Message */}
        {successMessage && (
          <div className={`alert alert-${successMessage === 'Products fetched successfully!' ? 'success' : 'danger'}`} role="alert">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="alert alert-danger" role="alert">
            {errorMessage}
          </div>
        )}
        {/* Form Error Message */}
        {formError && (
          <div className="alert alert-warning" role="alert">
            {formError}
          </div>
        )}<div className="mt-4">

        </div>
        <h2>Select Api Type</h2>
        <CRow>
          <CCol md="6">
            <label>
              <input
                type="radio"
                value="TMAPI"
                checked={selectedForm === "TMAPI"}
                onChange={handleCheckboxChanged}
              />
              TMAPI
            </label>
          </CCol>
          <CCol md="6">
            <label>
              <input
                type="radio"
                value="OTCOMMERCE"
                checked={selectedForm === "OTCOMMERCE"}
                onChange={handleCheckboxChanged}
              />
              OTCOMMERCE
            </label>
          </CCol>
        </CRow>

        {/* Form to filter products */}
        {selectedForm === "TMAPI" && (
          <DynamicForm />
        )}

        {selectedForm === "OTCOMMERCE" && (

          <form onSubmit={handleSubmit} className="mt-4">
            {
        /* <CRow>
            <CCol md="6">
              <CFormLabel>Provider Url</CFormLabel>
              <CFormInput
                type="text"
                value={providerurl}
                onChange={(e) => setProviderUrl(e.target.value)}
              />
            </CCol>
            <CCol md="6">
              <CFormLabel>Provider Type</CFormLabel>
              <CFormSelect
                  id="provider"
                  value={provider}
                  onChange={(e) => setProvider(e.target.value)}
                  placeholder="Enter vendor name"
                  className="form-control-lg"
                >
                  <option value="">Select Vendor</option>
                  <option value="1688.com">1688.com</option>
                  <option value="Taobao">Таобао/TMall</option>
                  <option value="furniture">Alibaba</option>
                  <option value="eBay">eBay</option>
                  <option value="JD">JD</option>
                  <option value="AliExpress">
                  AliExpress (USA, Korea, Saudi Arabia, Singapore to choose from)</option>
                  <option value="Amazon">Amazon (USA, China to choose from)</option>
                  <option value="Pinduoduo">Pinduoduo</option>
                  <option value="Shein">Shein (Global)</option>
                  <option value="Trendyol">Trendyol (Turkish goods)</option>
                </CFormSelect>
            </CCol>
          </CRow>
         <h1>OR</h1> */}
            {/* <CRow>
            <CCol md="6">
              <CFormLabel>Langauge</CFormLabel>
                <CFormSelect
                  id="language"
                  value={language}
                  onChange={handleLanguageChange}
                >
                  <option value="">Select Language</option>
                  <option value="en">English (English)</option>
                  <option value="ru">Russian (русский)</option>
                  <option value="mn">Mongolian (Монгол хэл)</option>
                  <option value="zh">Chinese (中文)</option>
                  <option value="es">Spanish (Español)</option>
                  <option value="de">German (Deutsch)</option>
                  <option value="pt">Portuguese (Português)</option>
                  <option value="bg">Bulgarian (Български)</option>
                  <option value="he">Hebrew (עברית)</option>
                  <option value="hy">Armenian (հայերէն)</option>
                  <option value="sah">Yakut (Саха тыла)</option>
                  <option value="pl">Polish (Jezyk polski, polszczyzna)</option>
                  <option value="ka">Georgian (ქართული ენა)</option>
                  <option value="ro">Romanian (Limba română)</option>
                  <option value="uk">Ukrainian (Українська мова)</option>
                  <option value="fi">Finnish (Suomi)</option>
                  <option value="ja">Japanese (日本語)</option>
                  <option value="az">Azerbaijani (Azərbaycan dili)</option>
                  <option value="ky">Kyrgyz (Кыргыз тили)</option>
                  <option value="cs">Czech (čeština)</option>
                  <option value="ar">Arabic (العربية)</option>
                  <option value="ko">Korean (한국어)</option>
                  <option value="vi">Vietnamese (Tiếng Việt)</option>
                  <option value="fr">French (Français)</option>
                  <option value="my">Myanmar (မြန်မာစာ)</option>
                  <option value="kk">Kazakh (Қазақ тілі)</option>
                  <option value="ms">Malay (بهاس ملايو)</option>
                  <option value="uz">Uzbek (Оʻzbek tili)</option>
                  <option value="tr">Turkish (Türkçe)</option>
                  <option value="no">Norwegian (Norsk)</option>
                  <option value="km">Khmer (ភាសាខ្មែរ)</option>
                  <option value="th">Thai (ภาษาไทย)</option>
                  <option value="ku">Kurdish (زمانی کوردی)</option>
                  <option value="el">Greek (Ελληνικά)</option>
                  <option value="am">Amharic (አማርኛ)</option>
                </CFormSelect>

            </CCol>
          </CRow> */}
            {/* <CRow>
            <CCol md="3">
              <CFormLabel>Category</CFormLabel>
              <CFormInput
                type="text"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              />
            </CCol>
            <CCol md="3">
              <CFormLabel>Brand ID , Brand Name</CFormLabel>
              <CFormInput
                type="text"
                value={brand}
                onChange={(e) => setBrand(e.target.value)}
              />
            </CCol>
            <CCol md="3">
              <CFormLabel>Min Price</CFormLabel>
              <CFormInput
                type="number"
                value={minPrice}
                onChange={(e) => setMinPrice(e.target.value)}
              />
            </CCol>
            <CCol md="3">
              <CFormLabel>Max Price</CFormLabel>
              <CFormInput
                type="number"
                value={maxPrice}
                onChange={(e) => setMaxPrice(e.target.value)}
              />
            </CCol>
          </CRow> */}
            <CRow>
              {/* <CCol md="3">
              <CFormLabel>Item ID</CFormLabel>
              <CFormInput
                type="text"
                value={itemid}
                onChange={(e) => setItemid(e.target.value)}
              />
            </CCol> */}
              <CCol md="12">
                <CFormLabel>Item Title/Item URL</CFormLabel>
                <CFormInput
                  type="text"
                  value={itemtitle}
                  onChange={(e) => setItemtitle(e.target.value)}
                />
              </CCol>
              {/* <CCol md="3">
              <CFormLabel>Condition</CFormLabel>
              <CFormSelect
                value={condition}
                onChange={(e) => setCondition(e.target.value)}
              >
                <option value="">Select Condition</option>
                <option value="New">New</option>
                <option value="Used">Used</option>
              </CFormSelect>
            </CCol> */}
              {/* <CCol md="3">
              <CFormLabel>Vendor/ Vendor Id</CFormLabel>
              <CFormInput
                type="text"
                value={vendor}
                onChange={(e) => setVendor(e.target.value)}
              />
            </CCol> */}
              <h1>OR</h1>
              <CCol md="6">
                <CFormLabel>Seller ID</CFormLabel>
                <CFormInput
                  type="text"
                  value={seller}
                  onChange={(e) => setseller(e.target.value)}
                />
              </CCol>
              <CCol md="6">
                <CFormLabel>Seller URL</CFormLabel>
                <CFormInput
                  type="text"
                  value={sellerurl}
                  onChange={(e) => setSellerUrl(e.target.value)}
                />
              </CCol>
            </CRow>
            <CRow className="mt-3">
              <CCol md="12">
                <CButton color="primary" type="submit" size="lg" block>
                  Filter Products
                </CButton>
                <CButton
                  color="secondary"
                  onClick={handleClearFilters}
                  size="lg"
                  block
                  className="clear" style={{ float: 'right' }}
                >
                  Clear
                </CButton>
              </CCol>
            </CRow>
          </form>

        )}
        {/* Table with Product List */}

        <div className="mt-4">
          {selectedForm === "OTCOMMERCE" && (
            <h1>Product List</h1>
          )}
          {selectedForm === "OTCOMMERCE" && (
            <CRow className="mb-3">
              <CCol md="8">
                <CFormInput
                  placeholder="Search Products"
                  onChange={handleFilterChange}
                  className="form-control-lg"
                />
              </CCol>
            </CRow>
          )}
          {selectedForm === "OTCOMMERCE" && (
            <div className="table-responsive">
              <table className="table table-striped">
                <thead>
                  <tr>
                    <th>
                      <input
                        type="checkbox"
                        checked={selectAll}
                        onChange={handleSelectAllChange}
                      />
                    </th>
                    <th>Id</th>
                    <th>Provider Type</th>
                    <th>Brand Id</th>
                    <th>Title</th>
                    <th>Original Title</th>
                    <th>Vendor Name</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredProducts.length > 0 ? (
                    filteredProducts.map((product, index) => (
                      <tr key={index}>
                        <td>
                          <input
                            type="checkbox"
                            checked={selectedProducts.some(p => p.Id === product.Id)} // Check if the product is selected
                            onChange={() => handleCheckboxChange(product.Id)} // Handle individual checkbox selection
                          />
                        </td>
                        <td>{product.Id}</td>
                        <td>{product.ProviderType}</td>
                        <td>{product.BrandId}</td>
                        <td>{product.Title}</td>
                        <td>{product.OriginalTitle}</td>
                        <td>{product.VendorName}</td>
                        <td>
                          <CButton
                            color="info"
                            onClick={() => handleViewDetails(product)}
                          >
                            View Details
                          </CButton>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="8">No products found</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
          {/* Import Selected Products Button */}
          {selectedForm === "OTCOMMERCE" && (
            <CButton
              color="primary"
              onClick={handleImportSelectedProducts}
              disabled={loading}
              className="mt-3"
              block
            >
              {loading ? `Searching... ${progress}%` : 'Import Selected Products'}
            </CButton>
          )}
        </div>

        {/* Product Details Modal */}
        <CModal visible={modalVisible} onClose={handleCloseModal}>
          <CModalHeader>
            <CModalTitle>Product Details</CModalTitle>
          </CModalHeader>
          <CModalBody>
            <p>ID: {selectedProduct?.Id}</p>
            <p>Title: {selectedProduct?.Title}</p>
            <p>Brand: {selectedProduct?.BrandId}</p>
            <p>Provider: {selectedProduct?.ProviderType}</p>
            <p>Vendor: {selectedProduct?.VendorName}</p>
            {/* Add more details as needed */}
          </CModalBody>
          <CModalFooter>
            <CButton color="secondary" onClick={handleCloseModal}>
              Close
            </CButton>
          </CModalFooter>
        </CModal>

      </CCardBody>
    </CCard>
  );
};

export default Colors;