import React, { useState, useEffect } from 'react';
import { CRow, CCol, CFormLabel, CFormSelect, CFormInput, CButton } from '@coreui/react';
import BASE_URL from "../../../.././src/config";
const DynamicForm = () => {
  const [provider, setProvider] = useState('');
  const [itemid, setItemId] = useState('');
  const [itemUrl, setItemUrl] = useState('');
  const [tableData, setTableData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [selectedProducts, setSelectedProducts] = useState([]);
  const [errorMessage, setErrorMessage] = useState('');
  const [formError, setFormError] = useState('');
  const [products, setProducts] = useState([]);
// console.log("BASE_URL",BASE_URL);
  const handleProviderChange = (e) => {
    setProvider(e.target.value);
    setItemId('');
    setItemUrl('');
    setProducts([]);
    setSelectedProducts([]);
    
    // ✅ Reset messages when provider changes
    setSuccessMessage('');
    setErrorMessage('');
    setFormError('');
  };
  
  const handleSelectProduct = (itemId) => {
    setSelectedProducts((prev) =>
      prev.includes(itemId) ? prev.filter(id => id !== itemId) : [...prev, itemId]
    );
  };

  const handleSelectAll = () => {
    if (selectedProducts.length === products.length) {
      setSelectedProducts([]);
    } else {
      setSelectedProducts(products.map(item => item.item_id,));
    }
  };
  // useEffect(() => {
  //   const demoProduct = {
  //     code: 200,
  //     msg: "success",
  //     data: [
  //       {
  //         item_id: 100139643418,
  //         product_url: "https://item.jd.com/100139643418.html",
  //         title: "欧珀莱（AUPRES）臻粹轻龄玻尿酸淡纹水(滋润型)50mL",
  //         price_info: {
  //           price: "9.9",
  //           origin_price: "50.0"
  //         }
  //       }
  //     ]
  //   };
  //   setProducts(demoProduct.data);
  // }, []);


  const handleSubmit = async (e) => {
    e.preventDefault();
  
    if (!itemid.trim() && !itemUrl.trim()) {
      setFormError('At least one field must be filled, such as Item ID or Item URL.');
      return;
    }
  
    // ✅ Reset messages before fetching
    setSuccessMessage('');
    setErrorMessage('');
    setFormError('');
    setSelectedProducts([]);
  
    setLoading(true);
    const formData = { provider, itemid, itemUrl };
  
    try {
      // Ensure the path is correctly concatenated
      const url = new URL(`${BASE_URL}/get_filterproduct_api_bytmapi.php?task=getProducts`);
    
      // Append search params dynamically
      Object.keys(formData).forEach((key) => {
        if (formData[key]) url.searchParams.append(key, formData[key]);
      });
    
      const response = await fetch(url, { 
        method: 'GET', 
        headers: { 'Content-Type': 'application/json' } 
      });
    
      if (!response.ok) throw new Error('Failed to fetch products');
    
      const result = await response.json();
    
      if (result && result.data) {
        setProducts(Array.isArray(result.data) ? result.data : [result.data]);
        setSuccessMessage('Products fetched successfully!');
      } else {
        setProducts([]);
        setSuccessMessage('No products found!');
      }
    } catch (error) {
      setErrorMessage('No products found for the given filters.');
    } finally {
      setLoading(false);
    }
    
  };
  
  const handleSaveToDatabase = async () => {
    if (selectedProducts.length === 0) {
      setFormError('Please select at least one product.');
      return;
    }
  
    // ✅ Reset messages before saving
    setSuccessMessage('');
    setErrorMessage('');
  
    const selectedProductData = products
      .filter(item => selectedProducts.includes(item.item_id))
      .map(item => ({
        item_id: item.item_id,
        title: item.title,
        response: item,
        provider: provider,
        api_type: "tmapi"
      }));
  
    try {
      const response = await fetch(`${BASE_URL}/save_selected_products.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ selectedProducts: selectedProductData })
      });
      const result2 = await response.json();
      console.log(result2);
      if (result2.status!="success") throw new Error('Failed to save products');
      
      setSuccessMessage('Selected products saved successfully!');
    } catch (error) {
      setErrorMessage("Error saving product.");
    }
  };
  

  return (
    <div>
      {successMessage && <div className="alert alert-success">{successMessage}</div>}
      {errorMessage && <div className="alert alert-danger">{errorMessage}</div>}
      {formError && <div className="alert alert-warning">{formError}</div>}

      <form onSubmit={handleSubmit} className="mt-4">
        <CRow>
          <CCol md="12">
            <CFormLabel>Provider Type</CFormLabel>
            <CFormSelect
              id="provider"
              value={provider}
              onChange={handleProviderChange}
              placeholder="Enter vendor name"
              className="form-control-lg"
            >
              <option value="">Select Vendor</option>
              <option value="1688">1688.com</option>
              <option value="taobao">Таобао/TMall</option>
              {/* <option value="furniture">Alibaba</option> */}
              {/* <option value="eBay">eBay</option> */}
              <option value="jd">JD</option>
              <option value="aliexpress">
                AliExpress (USA, Korea, Saudi Arabia, Singapore to choose from)</option>
              {/* <option value="Amazon">Amazon (USA, China to choose from)</option> */}
              <option value="pdd">Pinduoduo</option>
              {/* <option value="Shein">Shein (Global)</option> */}
              {/* <option value="Trendyol">Trendyol (Turkish goods)</option> */}
            </CFormSelect>
          </CCol>
        </CRow>

        {(provider == "1688" || provider == "aliexpress" || provider == "taobao") && (
          <CRow className="mt-3">
            <CCol md="6">
              <CFormLabel>Search By Item Id</CFormLabel>
              <CFormInput type="text" value={itemid} onChange={(e) => setItemId(e.target.value)} placeholder="Enter Item ID" />
            </CCol>
            <CCol md="6">
              <CFormLabel>Search By Item Url</CFormLabel>
              <CFormInput type="text" value={itemUrl} onChange={(e) => setItemUrl(e.target.value)} placeholder="Enter Item URL" />
            </CCol>
          </CRow>
        )}
        {(provider == "jd" || provider == "pdd") && (
          <CRow className="mt-3">
            <CCol md="6">
              <CFormLabel>Search By Item Id</CFormLabel>
              <CFormInput type="text" value={itemid} onChange={(e) => setItemId(e.target.value)} placeholder="Enter Item ID" />
            </CCol>

          </CRow>
        )}
        <CRow className="mt-3">
          <CCol md="12">
            <CButton color="primary" type="submit" disabled={loading}>{loading ? 'Loading...' : 'Filter Products'}</CButton>
          </CCol>
        </CRow>
        <div className="table-responsive mt-3">
          <table className="table table-bordered">
            <thead>
              <tr>
                <th><input type="checkbox" onChange={handleSelectAll} checked={selectedProducts.length === products.length} /></th>
                <th>ID</th>
                <th>Title</th>
                <th>Price</th>
              </tr>
            </thead>
            <tbody>
              {products.length > 0 ? (
                products.map((item, index) => (
                  <tr key={index}>
                    <td><input type="checkbox" checked={selectedProducts.includes(item.item_id)} onChange={() => handleSelectProduct(item.item_id)} /></td>
                    <td>{item.item_id}</td>
                    <td>{item.title}</td>
                    <td>{item.price_info.price}</td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="3">No data available</td>
                </tr>
              )}
            </tbody>
          </table>
          <CButton color="primary" onClick={handleSaveToDatabase}>Save Selected Products</CButton>
        </div>


      </form>
    </div>
  );
};

export default DynamicForm;