import React, { useState, useEffect } from "react";
import { CRow, CCol, CCard, CCardBody, CButton, CCardHeader } from "@coreui/react";
import axios from "axios";
// import { useNavigate } from "react-router-dom"; // Import useNavigate from react-router-dom
import { Link } from 'react-router-dom';
const Colors = () => {
  const [products, setProducts] = useState([]);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const fetchData = async () => {
    try {
      const response = await fetch("https://readyforyourreview.com/ShahbazY12/api/api.php/records/products/", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();

      if (data.records && data.records.length > 0) {
        setProducts(data.records);
      } else {
        setErrorMessage("No existing data found.");
      }
    } catch (error) {
      setErrorMessage("Error fetching data from the server.");
      console.error(error);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <CCard className="mb-4">
      <CCardHeader>
        <h4>Product List</h4>
      </CCardHeader>
      <CCardBody>
        {successMessage && (
          <div className="alert alert-success" role="alert">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="alert alert-danger" role="alert">
            {errorMessage}
          </div>
        )}
        <div className="table-responsive">
          <table className="table table-striped">
            <thead>
              <tr>
                <th>Id</th>
                {/* <th>Brand Id</th> */}
                <th>Title</th>
                <th>Provider Type</th>
                {/* <th>Vendor Name</th> */}
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {products.length > 0 ? (
                products.map((product, index) => (
                  <tr key={index}>
                    <td>{product.id}</td>
                    <td>{product.title}</td>
                    {/* <td>{product.brand_id}</td> */}
                    <td>{product.provider_type}</td>
                    {/* <td>{product.vendorname}</td>                     */}
                    <td><Link to={`/theme/product_page?id=${product.id}`}><button className='btn btn-primary'>View</button></Link></td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6">No products found</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </CCardBody>
    </CCard>
  );
};

export default Colors;