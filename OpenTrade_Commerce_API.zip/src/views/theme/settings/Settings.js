import React, { useState, useEffect } from "react";
import { CRow, CCol, CCard, CCardBody, CButton, CFormLabel, CFormInput, CCardHeader } from "@coreui/react";
import axios from "axios";  // Add axios to make HTTP requests

const Colors = () => {
  const [keyword0, setKeyword0] = useState("");
  const [keyword1, setKeyword1] = useState("");
  const [keyword2, setKeyword2] = useState("");
  const [keyword3, setKeyword3] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [dataId, setDataId] = useState(null);  // Keep track of the ID to update the data

  // Function to fetch data from the database when the component mounts or after insertion
  const fetchData = async () => {
    try {
      const response = await fetch("https://readyforyourreview.com/ShahbazY12/api/api.php/records/addkey_settings_table", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      const data = await response.json();

      if (data.records && data.records.length > 0) {
        const keydata = data.records[0];  // Assuming there's only one record
        setKeyword0(keydata.keyword0 || "");
        setKeyword1(keydata.keyword1 || "");
        setKeyword2(keydata.keyword2 || "");
        setKeyword3(keydata.keyword3 || "");
        setDataId(keydata.id);  // Store the ID of the data to update later
      } else {
        setErrorMessage("No existing data found.");
      }
    } catch (error) {
      setErrorMessage("Error fetching data from the server.");
      console.error(error);
    }
  };

  // Fetch the data initially when the component mounts
  useEffect(() => {
    fetchData();
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSuccessMessage("");
    setErrorMessage("");

    const formData = {
      keyword0,
      keyword1,
      keyword2,
      keyword3,
    };

    try {
      let response;

      if (dataId) {
        // Update the existing data (PUT request)
        response = await axios.put(
          `https://readyforyourreview.com/ShahbazY12/api/api.php/records/addkey_settings_table/${dataId}`,
          formData
        );
        
        console.log("Response data:", response.data); // Log the response for debugging

        if (response.data == 1) {
          setSuccessMessage("Data updated successfully!");
          // Fetch the updated data after updating
          fetchData();
        } else {
          setErrorMessage(response.data.message || "Failed to update data.");
        }
      } else {
        // Insert new data (POST request)
        response = await axios.post(
          "https://readyforyourreview.com/ShahbazY12/api/api.php/records/addkey_settings_table",
          formData
        );

        console.log("Response data:", response.data); // Log the response for debugging

        if (response.data) {
          setSuccessMessage("New row inserted successfully!");
          // Fetch the updated data after insertion
          fetchData();
          // Reset the form
          setKeyword0("");
          setKeyword1("");
          setKeyword2("");
          setKeyword3("");
        } else {
          setErrorMessage(response.data.message || "Failed to insert data.");
        }
      }
    } catch (error) {
      setErrorMessage("Error connecting to the server.");
      console.error(error);
    }
  };

  return (
    <CCard className="mb-4">
      <CCardHeader>
        <h4>API Details</h4>
      </CCardHeader>
      <CCardBody>
        {successMessage && (
          <div className="alert alert-success" role="alert">
            {successMessage}
          </div>
        )}
        {errorMessage && (
          <div className="alert alert-danger" role="alert">
            {errorMessage}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <CRow className="mb-3">
            <CCol md="1">
              <CFormLabel htmlFor="keyword0">Key 0</CFormLabel>
            </CCol>
            <CCol md="6">
              <CFormInput
                id="keyword0"
                value={keyword0}
                onChange={(e) => setKeyword0(e.target.value)}
                className="form-control-lg"
              />
            </CCol>
          </CRow>
          <CRow className="mb-3">
            <CCol md="1">
              <CFormLabel htmlFor="keyword1">Key 1</CFormLabel>
            </CCol>
            <CCol md="6">
              <CFormInput
                id="keyword1"
                value={keyword1}
                onChange={(e) => setKeyword1(e.target.value)}
                className="form-control-lg"
              />
            </CCol>
          </CRow>
          <CRow className="mb-3">
            <CCol md="1">
              <CFormLabel htmlFor="keyword2">Key 2</CFormLabel>
            </CCol>
            <CCol md="6">
              <CFormInput
                id="keyword2"
                value={keyword2}
                onChange={(e) => setKeyword2(e.target.value)}
                className="form-control-lg"
              />
            </CCol>
          </CRow>
          <CRow className="mb-3">
            <CCol md="1">
              <CFormLabel htmlFor="keyword3">Key 3</CFormLabel>
            </CCol>
            <CCol md="6">
              <CFormInput
                id="keyword3"
                value={keyword3}
                onChange={(e) => setKeyword3(e.target.value)}
                className="form-control-lg"
              />
            </CCol>
          </CRow>
          <CRow className="mt-3">
            <CCol md="1" className="text-center">
              <CButton color="primary" type="submit" size="lg" className="px-4">
                Submit
              </CButton>
            </CCol>
          </CRow>
        </form>
      </CCardBody>
    </CCard>
  );
};

export default Colors;