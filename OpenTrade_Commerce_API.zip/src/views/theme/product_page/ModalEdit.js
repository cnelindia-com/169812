import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTimes } from "@fortawesome/free-solid-svg-icons";

const ModalEdit = ({ isModalOpen, closeModal, editText, setEditText, handleSubmitEdit }) => {
  if (!isModalOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal">
        <FontAwesomeIcon
          icon={faTimes}
          className="close-modal-icon"
          onClick={closeModal}
        />
        <h3>Edit</h3>
        <textarea
          value={editText}
          onChange={(e) => setEditText(e.target.value)}
          className="edit-textarea"
        />
        <div className="modal-buttons">
          <button onClick={handleSubmitEdit}>Save</button>
          {/* <button onClick={handleCancelEdit}>Cancel</button> */}
        </div>
      </div>
    </div>
  );
};

export default ModalEdit;
