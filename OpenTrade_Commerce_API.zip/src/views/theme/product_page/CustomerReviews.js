import React, { useState, useEffect } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faCheckCircle, faEdit, faTimes, faStar, faPlus, faPencilAlt } from "@fortawesome/free-solid-svg-icons";
import "./CustomerReviews.css"; // CSS for styling
import ImageModal from "./ImageModal";

const CustomerReviews = ({ bulkCustomerReviews, image_url }) => {
  const [reviews, setReviews] = useState([]);
  const [verify, setVerify] = useState("Verified Buyer");
  const [selectedImage, setSelectedImage] = useState("");

  // Update state when new reviews are passed
  useEffect(() => {
    if (bulkCustomerReviews) {
      setReviews(bulkCustomerReviews);
    }
  }, [bulkCustomerReviews]);

  const [editId, setEditId] = useState(null);
  const [editText, setEditText] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editField, setEditField] = useState("");
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("select"); // Active tab for the image modal

  const handleEditClick = (id, currentText, field) => {
    setEditId(id);
    setEditText(currentText);
    setEditField(field);
    setIsModalOpen(true);
  };

  const handleSubmitEdit = () => {
    const updatedReviews = reviews.map((review, index) => {
      if (index === editId) {
        if (editField === "verify") {
          setVerify(editText);
        }
        return { ...review, [editField]: editText };
      }
      return review;
    });
    setReviews(updatedReviews);
    setIsModalOpen(false);
    setEditId(null);
    setEditField("");
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditId(null);
    setEditField("");
  };

  const handleImageClick = (id) => {
    setEditId(id);
    setIsImageModalOpen(true);
  };

  const handleImageSelect = (image) => {
    setSelectedImage(image);
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const saveChanges = () => {
    const updatedReviews = reviews.map((review, index) => {
      if (index === editId) {
        return { ...review, image: selectedImage };
      }
      return review;
    });
    setReviews(updatedReviews);
    setIsImageModalOpen(false);
    setSelectedImage("");
    setEditId(null);
  };

  return (
    <section className="customer-reviews">
      <div className="review-star_heading">
        {[...Array(5)].map((_, i) => (
          <FontAwesomeIcon key={i} icon={faStar} className="star-icon" />
        ))}
      </div>
      <h2>Customers Love Their Fresh Air Experience</h2>
      <div className="reviews">
        {reviews.map((review, index) => (
          <div className="review-card group" key={index}>
            <div className="review-plus-icon-container">
              <div className="review-plus-icon" onClick={() => handleImageClick(index)}>
                <div className="plus-icon-background">
                  <FontAwesomeIcon icon={faPlus} className="plus-icon" />
                </div>
                <div className="plus-icon-vertical"></div>
                <div className="plus-icon-horizontal"></div>
              </div>
            </div>
            {review.image && <img src={review.image} alt="Selected" className="review-image" />}
            <div className="review-header">
              <span className="review-name">{review.name}</span>
              <FontAwesomeIcon
                icon={faPencilAlt}
                className="edit-icon"
                onClick={() => handleEditClick(index, review.name, "name")}
              />
            </div>
            <div className="review-header">
              <FontAwesomeIcon icon={faCheckCircle} className="verify-icon" />
              <span className="verify_buyer">{verify}</span>
              <FontAwesomeIcon
                icon={faPencilAlt}
                className="edit-icon"
                onClick={() => handleEditClick(index, verify, "verify")}
              />
            </div>
            <div className="review-star">
              {[...Array(5)].map((_, i) => (
                <FontAwesomeIcon key={i} icon={faStar} className="star-icon" />
              ))}
            </div>
            <div className="review-text-container">
              <p className="review-text">
                {review.review}
                <FontAwesomeIcon
                  icon={faPencilAlt}
                  className="edit-icon"
                  onClick={() => handleEditClick(index, review.review, "review")}
                />
              </p>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="modal-overlay">
          <div className="modal">
            <FontAwesomeIcon icon={faTimes} className="close-modal-icon" onClick={closeModal} />
            <h3>Edit Text</h3>
            <textarea
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              className="edit-textarea"
            />
            <div className="modal-buttons">
              <button onClick={handleSubmitEdit}>Save</button>
              <button onClick={closeModal}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      <ImageModal
        isOpen={isImageModalOpen}
        closeModal={() => setIsImageModalOpen(false)}
        image_url={image_url}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        handleImageSelect={handleImageSelect}
        handleFileUpload={handleFileUpload}
        saveChanges={saveChanges}
        selectedImage={selectedImage}
      />
    </section>
  );
};

export default CustomerReviews;