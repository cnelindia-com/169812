import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencilAlt } from "@fortawesome/free-solid-svg-icons";
import ImageModal from "./ImageModal";
import ModalEdit from "./ModalEdit";
import "./BenefitSection.css";

const BenfitSection = ({ benefits, initialMainProductImage, image_url, setmainProductImage, setButtonText }) => {
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("select");
  const [selectedImage, setSelectedImage] = useState("");
  const [editText, setEditText] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editType, setEditType] = useState("");
  const [buttonText, setLocalButtonText] = useState("Get Mine Now"); // Local button text state

  const handleImageClick = () => {
    setIsImageModalOpen(true);
  };

  const handleEditTitleClick = () => {
    setEditText(benefits.heading);
    setEditType("heading");
    setIsModalOpen(true);
  };

  const handleEditDescClick = () => {
    setEditText(benefits.description);
    setEditType("description");
    setIsModalOpen(true);
  };

  const handleEditButtonClick = () => {
    setEditText(buttonText);
    setEditType("button");
    setIsModalOpen(true);
  };

  const handleSubmitEdit = () => {
    if (benefits) {
      if (editType === "heading") {
        benefits.heading = editText;
      } else if (editType === "description") {
        benefits.description = editText;
      } else if (editType === "button") {
        setLocalButtonText(editText); // Update local button text
        setButtonText(editText); // Update parent button text
      }
    }
    setIsModalOpen(false);
  };

  const closeModal = () => {
    setEditText("");
    setIsModalOpen(false);
  };

  const handleImageSelect = (image) => {
    setSelectedImage(image);
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const saveChanges = () => {
    setmainProductImage(selectedImage);
    setIsImageModalOpen(false);
    setSelectedImage("");
  };

  return (
    <section className="benefit-section">
      {benefits && (
        <div className="product-info-section">
          <div className="product-info-container">
            <div className="product-info-image">
              <img src={initialMainProductImage} alt="Product" className="info-image" key={initialMainProductImage} />
              <FontAwesomeIcon icon={faPencilAlt} className="edit-icon" onClick={handleImageClick} />
            </div>

            <div className="product-info-content">
              <h2>
                {benefits.heading}
                <FontAwesomeIcon icon={faPencilAlt} className="edit-icon" onClick={handleEditTitleClick} />
              </h2>
              <p>
                {benefits.description}
                <FontAwesomeIcon icon={faPencilAlt} className="edit-icon" onClick={handleEditDescClick} />
              </p>
              <button className="info-button">
                {buttonText}
                <FontAwesomeIcon icon={faPencilAlt} className="edit-icon" onClick={handleEditButtonClick} />
              </button>
            </div>
          </div>
        </div>
      )}

      <ModalEdit
        isModalOpen={isModalOpen}
        closeModal={closeModal}
        editText={editText}
        setEditText={setEditText}
        handleSubmitEdit={handleSubmitEdit}
      />

      <ImageModal
        isOpen={isImageModalOpen}
        closeModal={() => setIsImageModalOpen(false)}
        image_url={image_url}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        handleImageSelect={handleImageSelect}
        handleFileUpload={handleFileUpload}
        saveChanges={saveChanges}
        selectedImage={selectedImage}
      />
    </section>
  );
};

export default BenfitSection;