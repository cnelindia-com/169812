import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faWind, faPaw, faPencilAlt } from "@fortawesome/free-solid-svg-icons";
import ImageModal from "./ImageModal"; // Assuming ImageModal is in the same directory
import "./FeatureSection.css"; // Import CSS for styling

const FeatureSection = ({ features_section_info, features_section, thirdMainImage, setthirdMainImage, image_url }) => {
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("select");
  const [selectedImage, setSelectedImage] = useState("");

  const handleImageClick = () => {
    setIsImageModalOpen(true);
  };

  const handleImageSelect = (image) => {
    setSelectedImage(image);
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const saveChanges = () => {
    setthirdMainImage(selectedImage);
    setIsImageModalOpen(false);
    setSelectedImage("");
  };

  return (
    <div className="air-purifier-section">
      <div className="section-container">
        {features_section_info && (
          <div className="centered-content">
            <h2>{features_section_info.title}</h2>
            <p>{features_section_info.description}</p>
          </div>
        )}

        <div className="left-features">
          {features_section.slice(0, 2).map((feature, index) => (
            <div className="feature-item" key={index}>

              <FontAwesomeIcon icon={faWind} className="feature-icon" />
              <div className="feature-text">
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="section-image">
          <img
            src={thirdMainImage}
            alt="LEVOIT Core Mini Air Purifier"
            className="product-image"
          />
          <FontAwesomeIcon icon={faPencilAlt} className="edit-icon" onClick={handleImageClick} />
        </div>

        <div className="right-features">
          {features_section.slice(2, 4).map((feature, index) => (
            <div className="feature-item" key={index}>
              <FontAwesomeIcon icon={faPaw} className="feature-icon" />
              <div className="feature-text">
                <h3>{feature.title}</h3>
                <p>{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <ImageModal
        isOpen={isImageModalOpen}
        closeModal={() => setIsImageModalOpen(false)}
        image_url={image_url}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        handleImageSelect={handleImageSelect}
        handleFileUpload={handleFileUpload}
        saveChanges={saveChanges}
        selectedImage={selectedImage}
      />
    </div>
  );
};

export default FeatureSection;