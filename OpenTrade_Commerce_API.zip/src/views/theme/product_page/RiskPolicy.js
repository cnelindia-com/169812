import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHeart, faPencilAlt } from "@fortawesome/free-solid-svg-icons";
import ModalEdit from "./ModalEdit"; // Import ModalEdit
import "./RiskPolicy.css";

const RiskPolicy = ({
  guaranteeHeading,
  guaranteeDescription,
  updateGuarantee, // Add updateGuarantee prop
}) => {
  const [editText, setEditText] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editType, setEditType] = useState("");
  const [riskButtonText, setRiskButtonText] = useState("Get Mine Now");

  const handleEditHeadingClick = () => {
    setEditText(guaranteeHeading);
    setEditType("heading");
    setIsModalOpen(true);
  };

  const handleEditDescriptionClick = () => {
    setEditText(guaranteeDescription);
    setEditType("description");
    setIsModalOpen(true);
  };

  const handleEditButtonClick = () => {
    setEditText(riskButtonText);
    setEditType("button");
    setIsModalOpen(true);
  };

  const handleSubmitEdit = () => {
    if (editType === "heading") {
      updateGuarantee({ heading: editText, description: guaranteeDescription });
    } else if (editType === "description") {
      updateGuarantee({ heading: guaranteeHeading, description: editText });
    } else if (editType === "button") {
      setRiskButtonText(editText);
    }
    setIsModalOpen(false);
  };

  const closeModal = () => {
    setEditText("");
    setIsModalOpen(false);
  };

  return (
    <div className="container risk_policy">
      <div className="content">
        <div className="heart-icon">
          <FontAwesomeIcon size="2x" icon={faHeart} className="feature-icon" />
        </div>

        <div className="text">
          <h2>
            {guaranteeHeading}
            <FontAwesomeIcon
              icon={faPencilAlt}
              className="edit-icon"
              onClick={handleEditHeadingClick}
            />
          </h2>
          <p>
            {guaranteeDescription}
            <FontAwesomeIcon
              icon={faPencilAlt}
              className="edit-icon"
              onClick={handleEditDescriptionClick}
            />
          </p>
        </div>

        <div className="risk_policycta">
          <a href="risk_button" className="btn">
            {riskButtonText}
          </a>
            <FontAwesomeIcon
              icon={faPencilAlt}
              className="edit-icon"
              onClick={handleEditButtonClick}
            />
        </div>
      </div>
      <ModalEdit
        isModalOpen={isModalOpen}
        closeModal={closeModal}
        editText={editText}
        setEditText={setEditText}
        handleSubmitEdit={handleSubmitEdit}
      />
    </div>
  );
};

export default RiskPolicy;