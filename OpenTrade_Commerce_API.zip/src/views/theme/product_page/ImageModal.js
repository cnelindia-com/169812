import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faTimes, faImage, faUpload } from "@fortawesome/free-solid-svg-icons";
import "./CustomerReviews.css"; // CSS for styling

const ImageModal = ({ isOpen, closeModal, image_url, activeTab, setActiveTab, handleImageSelect, handleFileUpload, saveChanges, selectedImage }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay">
      <div className="modal">
        <FontAwesomeIcon icon={faTimes} className="close-modal-icon" onClick={closeModal} />
        <h3>Select or Upload Image</h3>
        <div className="image-modal-tabs">
          <button className={activeTab === "select" ? "active" : ""} onClick={() => setActiveTab("select")}>
            <FontAwesomeIcon icon={faImage} /> Gallery Image
          </button>
          <button className={activeTab === "upload" ? "active" : ""} onClick={() => setActiveTab("upload")}>
            <FontAwesomeIcon icon={faUpload} /> Upload Image
          </button>
        </div>
        {activeTab === "select" && (
          <div className="image-gallery_box">
            {image_url.map((image, index) => (
              <div
                className={`image_view ${image === selectedImage ? "selected" : ""}`}
                key={index}
                onClick={() => handleImageSelect(image)}
              >
                <img src={image} alt={`Gallery ${index}`} />
              </div>
            ))}
          </div>
        )}
        {activeTab === "upload" && (
          <div className="upload-image">
            <div className="upload-drop-area">
              Drag & Drop to Upload or
              <input type="file" onChange={handleFileUpload} />
            </div>
          </div>
        )}
        <div className="modal-buttons">
          <button onClick={closeModal}>Cancel</button>
          <button onClick={saveChanges}>Save Changes</button>
        </div>
      </div>
    </div>
  );
};

export default ImageModal;