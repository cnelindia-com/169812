import React, { useState } from "react";
import './Button.css';
import { useSearchParams } from "react-router-dom";
import ImageSelectionPopup from './ImageSelectionPopup';
import axios from 'axios';
import BASE_URL from "../../../config";

const RegenrateProductData = ({ image_url, mainProductImage }) => {
    const [isPopupOpen, setIsPopupOpen] = useState(false);
    const [productData, setProductData] = useState(null);
    const [productTitle, setProductTitle] = useState('');
    const [productDescription, setProductDescription] = useState('');
    const [product, setProduct] = useState({});
    const [loading, setLoading] = useState(false);
    const [searchParams] = useSearchParams();
    const id = searchParams.get("id");

    const handleremultiplegenrate = () => {
        setIsPopupOpen(true);
    };

    // const handleregenrate = async () => {
    //     setLoading(true);
    //     const queryString = image_url.map(encodeURIComponent).join(",");
    //     try {
    //         // const response2 = await fetch(
    //         //     `${BASE_URL}/fullpageproductcontent_api.php/?image=${mainProductImage}`,
    //         //     {
    //         //         method: "GET",
    //         //         headers: { "Content-Type": "application/json" },
    //         //     }
    //         // );
    //         const response2 = await fetch(`${BASE_URL}/data_genrateusing_multipleimage.php?image=${queryString}`, {
    //             method: "GET",
    //             headers: { "Content-Type": "application/json" }
    //           });

    //         const data2 = await response2.json();

    //         if (data2.product_ai_data) {
    //             console.log("AI-Generated Content Found:", data2);

    //             const formData = {
    //                 product_id: id,
    //                 ai_generated_title: data2.product_ai_data.title,
    //                 ai_generated_description: data2.product_ai_data.description,
    //                 ai_response: JSON.stringify(data2.product_ai_data),
    //             };

    //             const checkResponse = await fetch(
    //                 `${BASE_URL}/api.php/records/product_page_data?filter=product_id,eq,${id}`,
    //                 {
    //                     method: "GET",
    //                     headers: { "Content-Type": "application/json" },
    //                 }
    //             );

    //             const checkData = await checkResponse.json();

    //             let saveResponse;
    //             if (checkData.records && checkData.records.length > 0) {
    //                 const recordId = checkData.records[0].id;
    //                 saveResponse = await axios.put(
    //                     `${BASE_URL}/api.php/records/product_page_data/${recordId}`,
    //                     formData,
    //                     { headers: { "Content-Type": "application/json" } }
    //                 );
    //                 console.log("✅ Updated Existing AI Data:", saveResponse.data);
    //             } else {
    //                 saveResponse = await axios.post(
    //                     `${BASE_URL}/api.php/records/product_page_data`,
    //                     formData,
    //                     { headers: { "Content-Type": "application/json" } }
    //                 );
    //                 console.log("✅ Saved New AI Data:", saveResponse.data);
    //             }

    //             if (saveResponse && saveResponse.data) {
    //                 setProductTitle(data2.product_ai_data.title);
    //                 setProductDescription(data2.product_ai_data.description);
    //                 setProduct(data2.product_ai_data);
    //             }
    //         }
    //     } catch (error) {
    //         console.error("❌ Error saving AI Data:", error);
    //     } finally {
    //         setLoading(false);
    //     }
    // };

    const closePopup = () => {
        setIsPopupOpen(false);
    };

    return (
        <div className="Button_component">
            <button className="regenrate_data_btn" onClick={handleremultiplegenrate}>
                REGENERATE
            </button>

            {isPopupOpen && (
                <ImageSelectionPopup onClose={closePopup} image_url={image_url} mode="regenrate"/>
            )}
            {loading && <div>Loading...</div>}
        </div>
    );
};

export default RegenrateProductData;