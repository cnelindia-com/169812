import React from "react";
// import "./ComparisonSection.css"; // Import CSS for styling

const ComparisonSection = ({ comparison_info, comparison }) => {
  return (
    <div className="product-details-section">
      {/* What Sets This Product Apart Section */}
      <div className="sets-apart-section">
        <div className="section-container">
          {/* Left Side: Description */}
          {comparison_info && (
            <div className="sets-apart-left">
              <h2>{comparison_info.title}</h2>
              <p>{comparison_info.description}</p>
              <div className="action-button">
                <button className="learn-more-btn">Learn More</button>
              </div>
            </div>
          )}

          {/* Right Side: Comparison Table */}
          <div className="sets-apart-right">
            <div className="comparison-table">
              <table>
                <thead>
                  <tr>
                    <th>Feature</th>
                    <th>LEVOIT Core Mini</th>
                    <th>Others</th>
                  </tr>
                </thead>
                {comparison && (
                  <tbody>
                    <tr>
                      <td>{comparison.quality}</td>
                      <td>✔️</td>
                      <td>❌</td>
                    </tr>
                    <tr>
                      <td>{comparison.durability}</td>
                      <td>✔️</td>
                      <td>❌</td>
                    </tr>
                    <tr>
                      <td>{comparison.uniqueness}</td>
                      <td>✔️</td>
                      <td>❌</td>
                    </tr>
                  </tbody>
                )}
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default ComparisonSection;
