import React, { useState } from 'react';
import './ImageSelectionPopup.css';
import { useSearchParams } from "react-router-dom";
import axios from "axios";
import BASE_URL from "../../.././config";
// const BASE_URL = "https://readyforyourreview.com/ShahbazY12/api/api.php/records/product_images";

const ImageSelectionPopup = ({ onClose, image_url,mode }) => {
    const [searchParams] = useSearchParams();
    const product_id = searchParams.get("id");
    // console.log("Product ID:", product_id);
    // console.log("image_url structure:", image_url); // ✅ Debugging
    // console.log("mod",mode);
    const [selectedImages, setSelectedImages] = useState([]);
    const [successMessage, setSuccessMessage] = useState("");
    const [errorMessage, setErrorMessage] = useState("");

    // ✅ Ensure images are in the correct format
    const images = Array.isArray(image_url) ? image_url : image_url?.image_url || [];  

    const handleImageToggle = (imageUrl) => {
        setSelectedImages((prevSelected) =>
            prevSelected.includes(imageUrl)
                ? prevSelected.filter((img) => img !== imageUrl)
                : [...prevSelected, imageUrl]
        );
    };
    const generateSignature = async (secret, timestamp) => {
        const encoder = new TextEncoder();
        const keyData = encoder.encode(secret);
        const messageData = encoder.encode(secret + timestamp);
    
        // ✅ Import HMAC-SHA256 key
        const key = await crypto.subtle.importKey(
            "raw",
            keyData,
            { name: "HMAC", hash: { name: "SHA-256" } },
            false,
            ["sign"]
        );
    
        // ✅ Generate HMAC signature
        const signatureBuffer = await crypto.subtle.sign("HMAC", key, messageData);
    
        // ✅ Convert signature to hexadecimal string
        const signatureArray = Array.from(new Uint8Array(signatureBuffer));
        return signatureArray.map(b => b.toString(16).padStart(2, "0")).join("").toUpperCase();
    };
    
    const handleTranslate = async () => {
        console.log("Images to translate:", selectedImages);

        try {
            for (const imageUrl of selectedImages) {
                const translatedData = await translateImage(imageUrl);
                const translatedImageUrl = translatedData.data?.imageUrl;

                console.log("Translated Image URL:", translatedImageUrl);

                if (!translatedImageUrl) {
                    console.error("No translated image URL received.");
                    continue;
                }

                try {
                    // Fetch existing record ID first
                    const fetchResponse = await fetch(
                        `${BASE_URL}/api.php/records/product_images?filter=product_id,eq,${product_id}&filter=image_url,eq,${encodeURIComponent(imageUrl)}`,
                        {
                            method: "GET",
                            headers: { "Content-Type": "application/json" },
                        }
                    );
                    const fetchData = await fetchResponse.json();
                    console.log("fetchData", fetchData);

                    if (!fetchData.records || fetchData.records.length === 0) {
                        console.error("No matching record found in database.");
                        continue;
                    }

                    const imageId = fetchData.records[0].id;

                    // Update with new translated image URL
                    const response = await axios.put(
                        `${BASE_URL}/api.php/records/product_images/${imageId}`,
                        { image_url: translatedImageUrl },
                        { headers: { "Content-Type": "application/json" } }
                    );

                    console.log("Response data:", response.data);

                    if (response.data == 1) {
                        setSuccessMessage("Data updated successfully!");
                    } else {
                        setErrorMessage("Failed to update data.");
                    }
                } catch (error) {
                    setErrorMessage("Error connecting to the server.");
                    console.error(error);
                }
            }
            onClose();
        } catch (error) {
            console.error("Translation error:", error);
        }
    };
    const handleRemoveText = async () => {
        console.log("Images for text removal:", selectedImages);

        try {
            for (const imageUrl of selectedImages) {
                const removedTextData = await removeTextFromImage(imageUrl);
                const newImageUrl = removedTextData.data?.imageUrl;

                if (!newImageUrl) {
                    console.error("No updated image URL received.");
                    continue;
                }

                try {
                    const fetchResponse = await fetch(
                        `${BASE_URL}/api.php/records/product_images?filter=product_id,eq,${product_id}&filter=image_url,eq,${encodeURIComponent(imageUrl)}`,
                        {
                            method: "GET",
                            headers: { "Content-Type": "application/json" },
                        }
                    );
                    const fetchData = await fetchResponse.json();

                    if (!fetchData.records || fetchData.records.length === 0) {
                        console.error("No matching record found in database.");
                        continue;
                    }

                    const imageId = fetchData.records[0].id;

                    const response = await axios.put(
                        `${BASE_URL}/api.php/records/product_images/${imageId}`,
                        { image_url: newImageUrl },
                        { headers: { "Content-Type": "application/json" } }
                    );

                    if (response.data == 1) {
                        setSuccessMessage("Text removed successfully!");
                    } else {
                        setErrorMessage("Failed to update data.");
                    }
                } catch (error) {
                    setErrorMessage("Error connecting to the server.");
                    console.error(error);
                }
            }
            onClose();
        } catch (error) {
            console.error("Text removal error:", error);
        }
    };

    const removeTextFromImage = async (imageUrl) => {
        const apiKey = "505044";
        const apiSecret = "IzZxXb1EU2a38fv6b1Pzxn6oeEw9eJZr";
        const timestamp = Date.now();
        const sign = await generateSignature(apiSecret, timestamp);
        const apiUrl = `https://api.aidc-ai.com/rest/ai/image/removal?partner_id=aidge&sign_method=sha256&sign_ver=v2&app_key=${apiKey}&timestamp=${timestamp}&sign=${sign}`;

        const requestData = {
            image_url: imageUrl,
            non_object_remove_elements: "[1,2,3,4]",
            object_remove_elements: "[1,2,3,4]"
        };

        const response = await fetch(apiUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json", "x-iop-trial": "true" },
            body: JSON.stringify(requestData),
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        return response.json();
    };
    // 🔹 Regenerate Data with Selected Images
  // ✅ Regenerate API Call
  const handleRegenerate = async () => {
    console.log("Images to regenerate:", selectedImages);
    if (selectedImages.length === 0) {
        alert("Please select at least one image for regeneration.");
        return;
    }

    // setLoading(true);
    const queryString = selectedImages.map(encodeURIComponent).join(",");
    try {
        const response = await fetch(`${BASE_URL}/data_genrateusing_multipleimage.php?image=${queryString}`, {
            method: "GET",
            headers: { "Content-Type": "application/json" }
        });

        const data = await response.json();

        if (data.product_ai_data) {
            console.log("AI-Generated Content Found:", data);

            const formData = {
                product_id: product_id, // ✅ Fixed incorrect variable
                ai_generated_title: data.product_ai_data.title,
                ai_generated_description: data.product_ai_data.description,
                ai_response: JSON.stringify(data.product_ai_data),
            };

            const checkResponse = await fetch(
                `${BASE_URL}/api.php/records/product_page_data?filter=product_id,eq,${product_id}`,
                {
                    method: "GET",
                    headers: { "Content-Type": "application/json" },
                }
            );

            const checkData = await checkResponse.json();

            let saveResponse;
            if (checkData.records && checkData.records.length > 0) {
                const recordId = checkData.records[0].id;
                saveResponse = await axios.put(
                    `${BASE_URL}/api.php/records/product_page_data/${recordId}`,
                    formData,
                    { headers: { "Content-Type": "application/json" } }
                );
            } else {
                saveResponse = await axios.post(
                    `${BASE_URL}/api.php/records/product_page_data`,
                    formData,
                    { headers: { "Content-Type": "application/json" } }
                );
            }
        }
    } catch (error) {
        console.error("❌ Error saving AI Data:", error);
    } finally {
        // setLoading(false);
        onClose(); // ✅ Close popup after request
    }
};
    const translateImage = async (imageUrl) => {
        const apiKey = "504306";
        const apiSecret = "EICiICo3le8LRClwRSzW6PJs6eqkXIlu";
        const sourceLanguage = "zh";
        const targetLanguage = "en";
        const timestamp = Date.now();
        
        // ✅ Generate the "sign" using the function
        const sign = await generateSignature(apiSecret, timestamp);
    
        const apiUrl = `https://api.aidc-ai.com/rest/ai/image/translation?partner_id=aidge&sign_method=sha256&sign_ver=v2&app_key=${apiKey}&timestamp=${timestamp}&sign=${sign}`;
    
        const requestData = {
            imageUrl,
            sourceLanguage,
            targetLanguage,
            translatingTextInTheProduct: "false",
            useImageEditor: "false",
        };
    
        const response = await fetch(apiUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json", "x-iop-trial": "true" },
            body: JSON.stringify(requestData),
        });
    
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
    
        return response.json();
    };
    
    

    return (
        <div className="popup-overlay">
            <div className="popup-content">
                <h2>Select Images for Translation</h2>
                {successMessage && <p className="success-message">{successMessage}</p>}
                {errorMessage && <p className="error-message">{errorMessage}</p>}
                
                {/* ✅ Ensure images are properly mapped */}
                <div className="image-grid">
                    {images.length > 0 ? (
                        images.map((imageUrl, index) => (
                            <div
                                key={index}
                                className={`image-item ${selectedImages.includes(imageUrl) ? "selected" : ""}`}
                                onClick={() => handleImageToggle(imageUrl)}
                            >
                                <img src={imageUrl} alt="Image" />
                            </div>
                        ))
                    ) : (
                        <p>No images available.</p> // ✅ Show message if no images found
                    )}
                </div>

                <div className="popup-buttons">
                {mode === "translate" ? (
                        <>
                            <button onClick={handleTranslate}>Translate</button>
                            <button onClick={handleRemoveText}>Remove Text</button>
                        </>
                    ) : (
                        <button onClick={handleRegenerate}>Regenerate</button>
                    )}     
                    <button onClick={onClose}>Close</button>
                </div>
            </div>
        </div>
    );
};

export default ImageSelectionPopup;
