import React, { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import './product_page.css'; // Custom CSS for the page
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCheck, faStar, faCheckCircle, faPencilAlt, faTimes, faShippingFast, faUndoAlt, faHeart, faChevronDown, faChevronUp, faWind, faBed, faPaw, faSpa } from '@fortawesome/free-solid-svg-icons';
import CustomerReviews from "./CustomerReviews";
import BenfitSection from "./BenfitSection";
import FeatureSection from "./FeatureSection";
import PerformanceSection from "./PerformanceSection";
import ComparisonSection from "./ComparisonSection";
import ModalEdit from "./ModalEdit";
import RiskPolicy from "./RiskPolicy";
import ProductImageCarousel from "./ProductImageCarousel";
import SameButton from "./Button";
import axios from "axios";
import BASE_URL from "../../.././config";

const ProductDetails = () => {
  const [product, setProduct] = useState([]);
  const [image_url, setImageUrl] = useState([]);
  const [editText, setEditText] = useState(""); // Track the edited text
  const [isModalOpen, setIsModalOpen] = useState(false); // Control modal visibility
  const [productReview, setProductReview] = useState(120);
  const [oneproductReview, setOneProductReview] = useState([]);
  const [productTitle, setProductTitle] = useState(product.title);
  const [productPrice, setProductPrice] = useState(null);
  // const [productVendor, setProductVendor] = useState(product.vendor);
  const [productDescription, setProductDescription] = useState(product.description);
  const [editType, setEditType] = useState(''); // Track if we're editing title or review
  const [editIndex, setEditIndex] = useState(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [searchParams] = useSearchParams();
  const id = searchParams.get("id"); // ✅ Extract 'id' from query string
  const [guaranteeHeading, setguaranteeHeading] = useState(null);
  const [guaranteeDescription, setguaranteeDescription] = useState(null);
  const [colorVariants, setColorVariants] = useState([]);
  const [benefits, setBenefits] = useState(null);
  const [performance, setPerformance] = useState([]);
  const [performance_info, setPerformanceInfo] = useState(null);
  const [features_section, setfeature] = useState([]);
  const [comparison, setComparison] = useState([]);
  const [comparison_info, setComparisonInfo] = useState([]);
  const [BulkCustomerReviews, setCustomerReview] = useState([]);
  const [keyfeature, setkeyfeature] = useState([]);
  const [ShortDescription, setShortDescription] = useState(null);
  const [features_section_info, setfeatureInfo] = useState(null);
  const [mainProductImage, setmainProductImage] = useState(null);
  const [secondMainImage, setsecondMainImage] = useState("");
  const [thirdMainImage, setthirdMainImage] = useState("");
  const [loading, setLoading] = useState(false);
  const updatePerformance = (newPerformanceInfo, newPerformance) => {
    setPerformanceInfo(newPerformanceInfo);
    setPerformance(newPerformance);
  };
  const updateGuarantee = (newGuarantee) => {
    setguaranteeHeading(newGuarantee.heading);
    setguaranteeDescription(newGuarantee.description);
  };
  const saveProductImages = async (product_id, images) => {
    try {
      // 🔹 Pehle check karenge ki existing images database me hain ya nahi
      const checkResponse = await fetch(
        `${BASE_URL}/api.php/records/product_images?filter=product_id,eq,${product_id}`,
        {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        }
      );

      const checkData = await checkResponse.json();
      const existingImages = checkData.records?.map(item => item.image_url) || [];

      // 🔹 Sirf naye images ko save karenge (jo database me nahi hain)
      const newImages = images.filter(imageUrl => !existingImages.includes(imageUrl));

      for (const imageUrl of newImages) {
        const formData = {
          product_id: product_id,
          image_url: imageUrl,
        };

        const response = await fetch(
          `${BASE_URL}/api.php/records/product_images`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formData),
          }
        );

        const result = await response.json();
        console.log("Saved New Image Response:", result);
      }
    } catch (error) {
      console.error("Error saving images:", error);
    }
  };

  const fetchSavedProductImages = async (product_id) => {
    try {
      const response = await fetch(
        `${BASE_URL}/api.php/records/product_images?filter=product_id,eq,${product_id}`,
        {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        }
      );

      const data = await response.json();
      console.log("data", data);
      return data.records?.map(item => item.image_url) || []; // Return saved images
    } catch (error) {
      console.error("Error fetching saved images:", error);
      return []; // Return empty array if error
    }
  };

  const fetchData = async () => {
    try {
      if (!id) {
        setErrorMessage("Product ID is missing.");
        return;
      }

      // Fetch Product Data from Database
      const response1 = await fetch(
        `${BASE_URL}/api.php/records/products/${id}`,
        {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        }
      );

      const data1 = await response1.json();
      if (!data1.main_image_url) {
        setErrorMessage("Main image URL not found.");
        return;
      }

      const mainImageUrl = data1.main_image_url;

      const product_response = data1.response;
      const parseproduct_response = JSON.parse(product_response);
      const allPictures = parseproduct_response.main_imgs;
      setProductPrice(parseproduct_response.price_info.price);
      // Save Images to the API Table
      // / 🔹 Pehle database me check karenge saved images
      let savedImages = await fetchSavedProductImages(id);

      // 🔹 Agar database me koi image nahi hai, toh API response ka data use karein
      if (savedImages.length === 0) {
        await saveProductImages(id, allPictures); // Pehle database me save karein
        savedImages = allPictures; // Fallback to API images
      }

      // 🔹 State me saved images set karein
      setImageUrl(savedImages);
      setMainImage(savedImages[0] || ""); // Default to first image
      setmainProductImage(savedImages[0] || "");
      setsecondMainImage(savedImages[1] || ""); // Second image
      setthirdMainImage(savedImages[2] || ""); // Third image

      // setImageUrl(allPictures);
      // setImageUrl(allPictures);
      // setMainImage(allPictures[0]); // Set first image as main image
      // setsecondMainImage(allPictures[2]); // Set second image as main image
      // setthirdMainImage(allPictures[1]); // Set third image as main image
      // console.log("gdfg",allPictures);
      // Check if AI-generated content exists in the database
      const checkResponse = await fetch(
        `${BASE_URL}/api.php/records/product_page_data?product_id=${id}`,
        {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        }
      );

      const checkData = await checkResponse.json();
      const filteredData = checkData.records?.find(item => item.product_id == id);

      if (filteredData) {
        console.log("Filtered Data Found:", filteredData);
        setProductTitle(filteredData.ai_generated_title);
        setProductDescription(filteredData.ai_generated_description);
        setProduct(filteredData);
        setLoading(false);

        // Extract AI Response
        const aiResponse = JSON.parse(filteredData.ai_response);

        setguaranteeHeading(aiResponse.guarantee_section.heading);
        setguaranteeDescription(aiResponse.guarantee_section.description);
        setOneProductReview(aiResponse.customer_reviews);
        setColorVariants(aiResponse.color_variants);
        setBenefits(aiResponse.benefits_section);
        setPerformance(aiResponse.performance_metrics);
        setPerformanceInfo(aiResponse.performance_metrics_info);
        setfeatureInfo(aiResponse.features_section_info);
        setfeature(aiResponse.features_section);
        setComparisonInfo(aiResponse.comparison_table_info);
        setComparison(aiResponse.comparison_table);
        setCustomerReview(aiResponse.bulk_customer_reviews);
        setShortDescription(aiResponse.short_description);
        setkeyfeature(aiResponse.key_features);
        // ✅ **Since data exists, return early (Do not fetch AI API again)**
        return;
      }
      // 🔹 Convert array to comma-separated string
      // const queryString = allPictures.map(encodeURIComponent).join(",");
      // 🚀 **If AI-generated content is NOT found, then fetch it**
      console.log("Fetching AI-generated content...");
      
      setLoading(true);
      const response2 = await fetch(
        `${BASE_URL}/fullpageproductcontent_api.php/?image=${mainImageUrl}`,
        {
          method: "GET",
          headers: { "Content-Type": "application/json" },
        }
      );
      // const response2 = await fetch(`${BASE_URL}/data_genrateusing_multipleimage.php?image=${queryString}`, {
      //   method: "GET",
      //   headers: { "Content-Type": "application/json" }
      // });

      const data2 = await response2.json();
      if (data2.product_ai_data) {
        console.log("AI-Generated Content Found:", data2);
        setLoading(false);
        const formData = {
          product_id: id,
          ai_generated_title: data2.product_ai_data.title,
          ai_generated_description: data2.product_ai_data.description,
          ai_response: JSON.stringify(data2.product_ai_data),
        };

        try {
          const saveResponse = await axios.post(
            `${BASE_URL}/api.php/records/product_page_data`,
            formData
          );

          console.log("Saved AI Data Response:", saveResponse.data);

          // Set AI Data in State
          setProductTitle(data2.product_ai_data.title);
          setProductDescription(data2.product_ai_data.description);
          setProduct(data2.product_ai_data);
          setLoading(false);
        } catch (error) {
          console.error("Error saving AI Data:", error);
        }
      }
    } catch (error) {
      setErrorMessage("Error fetching data from the server.");
      console.error(error);
    }
  };


  useEffect(() => {
    if (id) {
      fetchData();
    }
  }, [id]);

  // Handle when the user clicks on the review edit icon
  const handleEditReviewClick = () => {
    setEditText(productReview); // Set the review text for the modal
    setEditType('review'); // Indicate we're editing the review
    setIsModalOpen(true); // Open the modal
  };

  // Handle when the user clicks on the title edit icon
  const handleEditTitleClick = () => {
    setEditText(productTitle); // Set the title text for the modal
    setEditType('title'); // Indicate we're editing the title
    setIsModalOpen(true); // Open the modal
  };

  // Handle when the user clicks on the title edit icon
  const handleEditVendorClick = () => {
    setEditText(productVendor); // Set the title text for the modal
    setEditType('vendor'); // Indicate we're editing the title
    setIsModalOpen(true); // Open the modal
  };

  const handleEditDescriptionClick = () => {

    setEditType('description'); // Indicate we're editing the description
    setEditText(productDescription); // Set the current description text for editing
    setIsModalOpen(true); // Open the modal
  };
  const handleEditkeyClick = (index) => {
    setEditIndex(index); // ✅ Store index
    setEditType('key'); // Indicate we're editing the description
    setEditText(keyfeature[index]); // Set current text for editing
    setIsModalOpen(true); // Open the modal
  };
  const handleEditshortDescriptionClick = () => {

    setEditType('short'); // Indicate we're editing the description
    setEditText(ShortDescription); // Set the current description text for editing
    setIsModalOpen(true); // Open the modal
  };

  // Handle the submit of the edited review or title
  const handleSubmitEdit = () => {
    if (editType === 'review') {
      setProductReview(editText);
    } else if (editType === 'title') {
      setProductTitle(editText);
    } else if (editType === 'vendor') {
      setProductVendor(editText);
    } else if (editType === 'short') {
      setShortDescription(editText);
    } else if (editType === 'description') {
      setProductDescription(editText); // Set the updated description list
      setEditIndex(null); // Reset the index
    }
    // else if (editType === 'key') {
    //   const updatedDescription = [keyfeature];
    //   updatedDescription[editIndex] = editText; // Update with the edited text, not the entire array.
    //   setkeyfeature(editText); // Set the updated description list
    //   setEditIndex(null); // Reset the index
    // }
    else if (editIndex !== null) {
      // ✅ Correct way to update array
      const updatedFeatures = [...keyfeature]; // Create a proper copy
      updatedFeatures[editIndex] = editText; // ✅ Update only the selected item

      setkeyfeature(updatedFeatures); // ✅ Save updated array
      setEditIndex(null); // ✅ Reset edit state
      setEditText("");
      setIsModalOpen(false); // ✅ Close modal
    }
    setIsModalOpen(false);
  };

  const closeModal = () => {
    setEditText("");   // Clear the text
    setEditIndex(null); // Reset the editIndex if needed
    setIsModalOpen(false); // Assuming you're using this state to control modal visibility
  };



  // Use state to manage the quantity
  const [quantity, setQuantity] = useState(1);

  // Handle increase button click
  const increaseQuantity = () => {
    setQuantity((prevQuantity) => prevQuantity + 1);
  };

  // Handle decrease button click
  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity((prevQuantity) => prevQuantity - 1);
    }
  };

  // Dynamic star rating display
  // const stars = Array.from({ length: 5 }, (_, index) =>
  //   index < Math.floor(70) ? '⭐' : '⭐'
  // ).join('');

  // Accordion state management
  const [isShippingOpen, setShippingOpen] = useState(false);
  const [isReturnOpen, setReturnOpen] = useState(false);

  const toggleShipping = () => setShippingOpen(!isShippingOpen);
  const toggleReturn = () => setReturnOpen(!isReturnOpen);

  // State to manage the main image
  const [mainImage, setMainImage] = useState();

  // Function to change the main image when a thumbnail is clicked
  const handleThumbnailClick = (image) => {
    setMainImage(image);
  };
  if (loading) {
    return (
      <div className="loading-overlay">
        <div className="loader"></div>
        <p>Generating the product page, please wait...</p>
      </div>
    );
  }

  return (
    <div className="product-page">
      <SameButton image_url={image_url} mainProductImage={mainProductImage} />
      <div className="product-container">
        {/* Product Image Section */}
        <ProductImageCarousel mainImage={mainImage} image_url={image_url} handleThumbnailClick={handleThumbnailClick} />
        {/* Product Details Section */}
        <div className="product-details">
          <div className="product-rating">
            <span>{[...Array(5)].map((_, i) => (
              <FontAwesomeIcon key={i} icon={faStar} className="star-icon" />
            ))}</span>
            <span> {productReview} Reviews</span>
            <FontAwesomeIcon
              icon={faPencilAlt}
              className="edit-icon"
              onClick={() => handleEditReviewClick(productReview)}
            />
          </div>
          <h1 className="product-title">{productTitle}<FontAwesomeIcon
            icon={faPencilAlt}
            className="edit-icon"
            onClick={() => handleEditTitleClick(productTitle)}
          /></h1>
          {/* { <p className="product-vendor">By {productVendor}<FontAwesomeIcon
            icon={faEdit}
            className="edit-icon"
           onClick={() => handleEditVendorClick(productVendor)}
          /></p>} */}
          <div className="product-description">
            <p>{ShortDescription}<FontAwesomeIcon
              icon={faPencilAlt}
              className="edit-icon"
              onClick={() => handleEditshortDescriptionClick(ShortDescription)}
            /></p>
          </div>
          {/* Product Description */}
          <div className="product-short-description">
            <ul>
              {Array.isArray(keyfeature) && keyfeature.length > 0 ? (
                keyfeature.map((key_des, index) => (
                  <li key={index}>
                    <FontAwesomeIcon icon={faCheck} className="check_icon" /> {key_des}
                    <FontAwesomeIcon
                      icon={faPencilAlt}
                      className="edit-icon"
                      onClick={() => handleEditkeyClick(index)}
                    />
                  </li>
                ))
              ) : (
                <li>No key features available.</li>
              )}
            </ul>
          </div>
          <p className="product-price">${productPrice}</p>
          {/* <div className="product-description">
            <p>{productDescription}<FontAwesomeIcon
              icon={faPencilAlt}
              className="edit-icon"
              onClick={() => handleEditDescriptionClick(productDescription)}
            /></p>
          </div> */}

          {/* <hr></hr> */}
          {/* Quantity Section */}
          <div className="info-section">
            <h4>Quantity</h4>
            <div className="quantity-selector">
              <button data-type="first"
                className="quantity-btn"
                onClick={decreaseQuantity}
                disabled={quantity === 1}
              >
                -
              </button>
              <input
                type="text"
                id="quantity"
                value={quantity}
                min="1"
                readOnly
              />
              <button data-type="second" className="quantity-btn" onClick={increaseQuantity}>
                +
              </button>
            </div>
          </div>

          {/* Style Section */}
          <div className="info-section">
            <h4>STYLE</h4>
            <div className="style-selector">
              <button className="style-btn" id="style1">Style1</button>
              <button className="style-btn" id="style2">Style2</button>
            </div>
          </div>
          <div className="info-section">
            <h4>COLOR</h4>
            <div className="color-selector">
              {colorVariants.map((color, index) => (
                <button key={index} className="color-btn" id="style1">{color}</button>
              ))}
            </div>
          </div>


          {/* Add to Cart Button */}
          <div className="product-actions">
            <button className="add-to-cart">Add to Cart</button>
          </div>

          {/* Shipping buttons */}
          <div className="product-guarantees">
            <div className="guarantee-item">
              <FontAwesomeIcon icon={faShippingFast} /> {/* Fast Shipping icon */}
              <span>Fast Shipping</span>
            </div>
            <div className="guarantee-item">
              <FontAwesomeIcon icon={faUndoAlt} /> {/* Free Returns icon */}
              <span>Free Returns</span>
            </div>
            <div className="guarantee-item">
              <FontAwesomeIcon icon={faHeart} />
              <span>30-Day Money Back <br></br> Guarantee</span>
            </div>
          </div>
          <hr></hr>
          {/* Review Section */}
          <div className="product-review">
            {oneproductReview.map((review, index) => (
              <div className="review-content" key={index}>
                <img
                  src="https://pagepilot.ai/images/reviews/woman32.webp"
                  alt={review.name}
                  className="review-image"
                />
                <div className="review-text">
                  <h3 className="review-heading">{[...Array(5)].map((_, i) => (
                    <FontAwesomeIcon key={i} icon={faStar} className="star-icon" />
                  ))}</h3>
                  <p>{review.review}</p>
                  <div className="review-author">
                    <FontAwesomeIcon icon={faCheckCircle} className="verify-icon" />
                    <span>{review.name}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <hr></hr>
          {/* Shipping Information Accordion */}
          <div className="accordion">

            <div className="accordion-item">
              <div className="accordion-header" onClick={toggleShipping}>
                <FontAwesomeIcon icon={faShippingFast} className="accordion-icon" />
                <span>Shipping Information</span>
                <FontAwesomeIcon
                  icon={isShippingOpen ? faChevronUp : faChevronDown}
                  className="chevron-icon"
                />
              </div>
              {isShippingOpen && (
                <div className="accordion-content">
                  <p>This is the shipping information content. Provide shipping details here.</p>
                  <p>Top: We ship worldwide with various options.</p>
                  <p>Middle: Delivery times may vary depending on location.</p>
                  <p>Bottom: Track your order easily through our website.</p>
                </div>
              )}
            </div>
            <hr></hr>
            {/* Return Policy Accordion */}
            <div className="accordion-item">
              <div className="accordion-header" onClick={toggleReturn}>
                <FontAwesomeIcon icon={faUndoAlt} className="accordion-icon" />
                <span>Return Policy</span>
                <FontAwesomeIcon
                  icon={isReturnOpen ? faChevronUp : faChevronDown}
                  className="chevron-icon"
                />
              </div>
              {isReturnOpen && (
                <div className="accordion-content">
                  <p>This is the return policy content. Provide return details here.</p>
                  <p>Top: Returns are accepted within 30 days of purchase.</p>
                  <p>Middle: You can return items in their original condition.</p>
                  <p>Bottom: Please contact customer service to initiate a return.</p>
                </div>
              )}
            </div>
            <hr></hr>
          </div>
        </div>
        <BenfitSection
          benefits={benefits}
          initialMainProductImage={mainProductImage}
          image_url={image_url}
          setmainProductImage={setmainProductImage}
        />        {/* { product airpurify} */}
        {/* // Parent Component (where you're using FeatureSection) */}
        <FeatureSection
          features_section_info={features_section_info}
          features_section={features_section}
          thirdMainImage={thirdMainImage}
          setthirdMainImage={setthirdMainImage}
          image_url={image_url} // Pass the image_url prop
        />
        <ComparisonSection comparison_info={comparison_info} comparison={comparison} />
        <PerformanceSection
          secondMainImage={secondMainImage}
          productTitle={productTitle}
          performance_info={performance_info}
          performance={performance}
          setsecondMainImage={setsecondMainImage}
          image_url={image_url} // Pass the image_url prop
          updatePerformance={updatePerformance}
        />

        <RiskPolicy
          guaranteeHeading={guaranteeHeading}
          guaranteeDescription={guaranteeDescription}
          updateGuarantee={updateGuarantee}
        />
        <CustomerReviews bulkCustomerReviews={BulkCustomerReviews} image_url={image_url} />
        {/* Other content of your page */}
      </div>
      {/* Modal for editing review */}
      <ModalEdit
        isModalOpen={isModalOpen}
        closeModal={closeModal}
        editText={editText}
        setEditText={setEditText}
        handleSubmitEdit={handleSubmitEdit}
      />
    </div>

  );
};

export default ProductDetails;