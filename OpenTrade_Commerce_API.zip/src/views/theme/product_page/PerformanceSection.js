import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faPencilAlt } from "@fortawesome/free-solid-svg-icons";
import ImageModal from "./ImageModal";
import ModalEdit from "./ModalEdit"; // Import ModalEdit
import "./PerformanceSection.css";

const PerformanceSection = ({
  secondMainImage,
  productTitle,
  performance_info,
  performance,
  setsecondMainImage,
  image_url,
  updatePerformance, // Add updatePerformance prop
}) => {
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("select");
  const [selectedImage, setSelectedImage] = useState("");
  const [editText, setEditText] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editType, setEditType] = useState("");

  const handleImageClick = () => {
    setIsImageModalOpen(true);
  };

  const handleEditDescClick = () => {
    setEditText(performance_info.description);
    setEditType("description");
    setIsModalOpen(true);
  };

  const handlePerformCustSatClick = (custSat) => {
    setEditText(custSat.toString());
    setEditType("custSat");
    setIsModalOpen(true);
  };

  const handlePerformClinResClick = (clinRes) => {
    setEditText(clinRes);
    setEditType("clinRes");
    setIsModalOpen(true);
  };

  const handleSubmitEdit = () => {
    if (performance_info) {
      if (editType === "description") {
        performance_info.description = editText;
      } else if (editType === "custSat") {
        performance.forEach((perform) => {
          if (perform.CustomerSatisfaction.toString() === editText) {
            perform.CustomerSatisfaction = parseInt(editText);
          }
        });
      } else if (editType === "clinRes") {
        performance.forEach((perform) => {
          if (perform.ClinicalResults === editText) {
            perform.ClinicalResults = editText;
          }
        });
      }
      updatePerformance(performance_info, performance); // Update parent state
    }
    setIsModalOpen(false);
  };

  const closeModal = () => {
    setEditText("");
    setIsModalOpen(false);
  };

  const handleImageSelect = (image) => {
    setSelectedImage(image);
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const saveChanges = () => {
    setsecondMainImage(selectedImage);
    setIsImageModalOpen(false);
    setSelectedImage("");
  };

  return (
    <div className="container performance_section">
      <div className="row">
        <div className="col-left perform_image">
          <img
            src={secondMainImage}
            alt={productTitle}
            className="air-purifier-image"
          />
          <FontAwesomeIcon
            icon={faPencilAlt}
            className="edit-icon"
            onClick={handleImageClick}
          />
        </div>

        <div className="col-right">
          {performance_info && (
            <h2>
              {performance_info.description}
              <FontAwesomeIcon
                icon={faPencilAlt}
                className="edit-icon"
                onClick={handleEditDescClick}
              />
            </h2>
          )}

          {performance.map((perform, index) => (
            <div className="performance" key={index}>
              <div className="performance-item">
                <div className="circle">
                  <span>
                    {perform.CustomerSatisfaction}
                    <FontAwesomeIcon
                      icon={faPencilAlt}
                      className="edit-icon"
                      onClick={() =>
                        handlePerformCustSatClick(perform.CustomerSatisfaction)
                      }
                    />
                  </span>
                </div>
                <p>
                  {perform.ClinicalResults}
                  <FontAwesomeIcon
                    icon={faPencilAlt}
                    className="edit-icon"
                    onClick={() => handlePerformClinResClick(perform.ClinicalResults)}
                  />
                </p>
              </div>
              <hr />
            </div>
          ))}

          <div className="cta">
            <a href="#buy-now" className="btn">
              Get Mine Now
            </a>
          </div>
        </div>
      </div>
      <ImageModal
        isOpen={isImageModalOpen}
        closeModal={() => setIsImageModalOpen(false)}
        image_url={image_url}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        handleImageSelect={handleImageSelect}
        handleFileUpload={handleFileUpload}
        saveChanges={saveChanges}
        selectedImage={selectedImage}
      />
      <ModalEdit
        isModalOpen={isModalOpen}
        closeModal={closeModal}
        editText={editText}
        setEditText={setEditText}
        handleSubmitEdit={handleSubmitEdit}
      />
    </div>
  );
};

export default PerformanceSection;