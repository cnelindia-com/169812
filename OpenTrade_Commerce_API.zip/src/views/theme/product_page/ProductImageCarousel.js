import React, { useState } from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faChevronLeft, faChevronRight } from "@fortawesome/free-solid-svg-icons";
import './ProductImageCarousel.css'; // Custom CSS for the page
const ProductImageCarousel = ({ mainImage, image_url, handleThumbnailClick }) => {
  const [scrollPosition, setScrollPosition] = useState(0);

  const handleScroll = (direction) => {
    if (direction === "left") {
      setScrollPosition((prev) => Math.max(prev - 1, 0));
    } else {
      setScrollPosition((prev) => (prev + 5 < image_url.length ? prev + 1 : prev));
    }
  };

  return (
    <div className="product-image-carousel">
      {/* Main Image */}
      <img src={mainImage} alt="Main product" className="main-image" />

      {/* Thumbnail images with controlled scroll */}
      <div className="thumbnail-container">
        {image_url.length > 5 && (
          <button className="scroll-button left" onClick={() => handleScroll("left")}> 
            <FontAwesomeIcon icon={faChevronLeft} />
          </button>
        )}
        <div className="image-thumbnails">
          {image_url.slice(scrollPosition, scrollPosition + 5).map((image, index) => (
            <img
              key={index}
              src={image}
              alt={`Thumbnail ${scrollPosition + index + 1}`}
              className={`thumbnail ${mainImage === image ? "active" : ""}`}
              onClick={() => handleThumbnailClick(image)}
            />
          ))}
        </div>
        {image_url.length > 5 && (
          <button className="scroll-button right" onClick={() => handleScroll("right")}> 
            <FontAwesomeIcon icon={faChevronRight} />
          </button>
        )}
      </div>
    </div>
  );
};

export default ProductImageCarousel;