import React from 'react'
import WidgetsBrand from '../widgets/WidgetsBrand'
import WidgetsDropdown from '../widgets/WidgetsDropdown'
import { CRow, CCol, CCard, CCardBody, CCardTitle, CCardText } from '@coreui/react'

const Dashboard = () => {
  return (
    <>
      <WidgetsDropdown className="mb-4" />
      <WidgetsBrand className="mb-4" withCharts />
      
      {/* Table to display total products */}
      {/* <CRow className="mb-4">
        <CCol md="8" className="offset-md-2">
          <CCard className="shadow">
            <CCardBody>
              <CCardTitle style={{ fontSize: '24px', fontWeight: 'bold' }}>Product Information</CCardTitle>
              <table className="table table-bordered text-center">
                <thead>
                  <tr>
                    <th scope="col">Total Products</th>
                    <th scope="col">Value</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Total Products</td>
                    <td style={{ color: '#4caf50', fontSize: '20px', fontWeight: 'bold' }}>20</td>
                  </tr>
                </tbody>
              </table>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow> */}
    </>
  )
}

export default Dashboard
