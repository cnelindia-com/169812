const BASE_URL = "https://readyforyourreview.com/ShahbazY12/api";

export default BASE_URL;
